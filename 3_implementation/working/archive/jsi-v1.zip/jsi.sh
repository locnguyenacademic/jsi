. env.sh

eval $JAVA_CMD:./jsi.jar net.jsi.ui.Investor